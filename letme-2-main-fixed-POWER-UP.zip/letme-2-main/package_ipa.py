#!/usr/bin/env python3
"""
package_ipa.py — Safe IPA packager for a built iOS .app

Usage:
  python3 package_ipa.py /path/to/directory/containing/one/MyApp.app [output.ipa]

The directory must contain exactly one .app bundle (the built iOS application).
This script does NOT build the project; it only packages an already-built .app.
"""
import sys
import os
import shutil
import zipfile
from pathlib import Path

def find_single_app(project_dir: Path) -> Path:
    apps = list(project_dir.glob("*.app"))
    if len(apps) == 0:
        # also look one level deeper (common in xcarchive/Products/Applications)
        apps = list(project_dir.glob("*/*.app"))
    if len(apps) != 1:
        raise ValueError(
            f"Choose a project_dir containing exactly one iOS application (.app). "
            f"Found {len(apps)} in {project_dir}"
        )
    return apps[0]

def package_ipa(app_path: Path, output_ipa: Path):
    payload = output_ipa.parent / "Payload"
    if payload.exists():
        shutil.rmtree(payload)
    payload.mkdir(parents=True)
    dest = payload / app_path.name
    shutil.copytree(app_path, dest)
    # write zip
    with zipfile.ZipFile(output_ipa, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(payload):
            for name in files:
                full = Path(root) / name
                arcname = full.relative_to(payload.parent)
                zf.write(full, arcname)
    shutil.rmtree(payload)
    print(f"Wrote {output_ipa} ({output_ipa.stat().st_size} bytes)")

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(2)
    project_dir = Path(sys.argv[1]).resolve()
    if not project_dir.is_dir():
        raise SystemExit(f"Not a directory: {project_dir}")
    app = find_single_app(project_dir)
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else project_dir / f"{app.stem}-unsigned.ipa"
    package_ipa(app, out.resolve())

if __name__ == "__main__":
    try:
        main()
    except ValueError as e:
        print(f"ValueError: {e}", file=sys.stderr)
        sys.exit(1)